package com.redboost.app

import android.content.Context
import android.content.SharedPreferences
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.compose.runtime.mutableStateMapOf
import java.util.Locale

const val CPUF = "/sys/devices/system/cpu/cpu[0-9]*/cpufreq"

/** tab: perf (Shizuku/ADB), touch, root, screen. root=true => needs su. off==null => one-shot action. */
data class Tweak(
    val id: String, val tab: String, val title: String, val desc: String, val root: Boolean,
    val on: String, val off: String? = null, val risky: Boolean = false, val minSdk: Int = 0
)

data class Choice(
    val id: String, val tab: String, val title: String, val desc: String, val root: Boolean,
    val options: List<Pair<String, String>>, val minSdk: Int = 0
)

data class Action(val title: String, val desc: String, val root: Boolean, val cmd: String, val show: Boolean = true)

private const val GPU_DEV = "for d in /sys/class/devfreq/*gpu* /sys/class/devfreq/*mali*; do if [ -d \$d ]; then "

val TOGGLES = listOf(
    // ---------- Shizuku / ADB level ----------
    Tweak("fixedperf", "perf", "Fixed performance mode", "Keeps the device at sustained max performance (Android 12+)", false,
        "cmd power set-fixed-performance-mode-enabled true", "cmd power set-fixed-performance-mode-enabled false", minSdk = 31),
    Tweak("anim0", "perf", "Disable animations", "Window/transition/animator scale = 0 for snappier UI", false,
        "settings put global window_animation_scale 0; settings put global transition_animation_scale 0; settings put global animator_duration_scale 0",
        "settings put global window_animation_scale 1; settings put global transition_animation_scale 1; settings put global animator_duration_scale 1"),
    Tweak("doze", "perf", "Disable Doze", "Stops deep-sleep from killing background network", false,
        "dumpsys deviceidle disable", "dumpsys deviceidle enable"),
    Tweak("abatt", "perf", "Disable Adaptive Battery", "Prevents the system from restricting apps", false,
        "settings put global adaptive_battery_management_enabled 0", "settings put global adaptive_battery_management_enabled 1"),
    Tweak("standby", "perf", "Disable App Standby", "Apps keep full access to CPU/network", false,
        "settings put global app_standby_enabled 0", "settings put global app_standby_enabled 1"),
    Tweak("scanoff", "perf", "Stop background Wi-Fi/BLE scanning", "Less radio interference & wakeups", false,
        "settings put global wifi_scan_always_enabled 0; settings put global ble_scan_always_enabled 0",
        "settings put global wifi_scan_always_enabled 1; settings put global ble_scan_always_enabled 1"),
    Tweak("dnd", "perf", "Do Not Disturb (gaming)", "Priority-only notifications while playing", false,
        "cmd notification set_dnd priority", "cmd notification set_dnd off"),
    Tweak("lowlat", "perf", "Wi-Fi low-latency mode", "Lower ping in online games (Android 11+)", false,
        "cmd wifi force-low-latency-mode enabled", "cmd wifi force-low-latency-mode disabled", minSdk = 30),
    Tweak("stayon", "perf", "Keep screen on while charging", "Screen never sleeps on charger", false,
        "svc power stayon true", "svc power stayon false"),
    Tweak("autobright", "perf", "Disable auto-brightness", "Stable brightness/colors during play", false,
        "settings put system screen_brightness_mode 0", "settings put system screen_brightness_mode 1"),
    Tweak("blur", "perf", "Disable window blur", "Saves GPU (Android 12+)", false,
        "settings put global disable_window_blurs 1", "settings put global disable_window_blurs 0", minSdk = 31),
    Tweak("thermal", "perf", "Thermal override (no throttling)", "Tells the system thermal status = none. Device may get VERY hot.", false,
        "cmd thermalservice override-status 0", "cmd thermalservice reset", risky = true, minSdk = 29),
    // ---------- Touch ----------
    Tweak("longpress", "touch", "Fast long-press (250ms)", "Faster long-press recognition", false,
        "settings put secure long_press_timeout 250", "settings put secure long_press_timeout 400"),
    Tweak("multipress", "touch", "Fast multi-press (200ms)", "Faster double-tap detection", false,
        "settings put secure multi_press_timeout 200", "settings put secure multi_press_timeout 300"),
    Tweak("pointer", "touch", "Max pointer speed", "Higher pointer/touch speed", false,
        "settings put system pointer_speed 7", "settings put system pointer_speed 0"),
    // ---------- Screen / GFX ----------
    Tweak("hwoverlay", "screen", "Disable HW overlays", "Forces GPU composition (can help some games, uses more power)", false,
        "service call SurfaceFlinger 1008 i32 1", "service call SurfaceFlinger 1008 i32 0"),
    Tweak("msaa", "screen", "Force 4x MSAA", "Smoother edges in OpenGL ES 2.0 apps (device dependent)", false,
        "setprop debug.egl.force_msaa true", "setprop debug.egl.force_msaa false"),
    // ---------- ROOT ----------
    Tweak("cpumax", "root", "Lock CPU at max frequency", "min = max on every core (heats up!)", true,
        "for c in $CPUF; do m=\$(cat \$c/cpuinfo_max_freq); chmod 644 \$c/scaling_min_freq \$c/scaling_max_freq; echo \$m > \$c/scaling_max_freq; echo \$m > \$c/scaling_min_freq; done",
        "for c in $CPUF; do chmod 644 \$c/scaling_min_freq; cat \$c/cpuinfo_min_freq > \$c/scaling_min_freq; done"),
    Tweak("gpumax", "root", "Lock GPU at max frequency", "Adreno (kgsl) & Mali/devfreq GPUs: governor=performance, min=max", true,
        "g=/sys/class/kgsl/kgsl-3d0; if [ -d \$g ]; then echo performance > \$g/devfreq/governor; cat \$g/devfreq/max_freq > \$g/devfreq/min_freq; echo 1 > \$g/force_clk_on; echo 1 > \$g/force_bus_on; echo 1 > \$g/force_rail_on; echo 0 > \$g/throttling; fi; " +
            GPU_DEV + "echo performance > \$d/governor; cat \$d/max_freq > \$d/min_freq; fi; done; true",
        "g=/sys/class/kgsl/kgsl-3d0; if [ -d \$g ]; then echo msm-adreno-tz > \$g/devfreq/governor; echo 0 > \$g/force_clk_on; echo 0 > \$g/force_bus_on; echo 0 > \$g/force_rail_on; echo 1 > \$g/throttling; n=\$(tr ' ' '\\n' < \$g/devfreq/available_frequencies | sort -n | head -1); echo \$n > \$g/devfreq/min_freq; fi; " +
            GPU_DEV + "echo simple_ondemand > \$d/governor; n=\$(tr ' ' '\\n' < \$d/available_frequencies | sort -n | head -1); echo \$n > \$d/min_freq; fi; done; true"),
    Tweak("allcores", "root", "Bring all CPU cores online", "Forces every core online (resets on reboot)", true,
        "for c in /sys/devices/system/cpu/cpu[0-9]*/online; do echo 1 > \$c; done; true"),
    Tweak("stune", "root", "Boost foreground (top-app) priority", "schedtune/uclamp boost for the app you're using", true,
        "[ -e /dev/stune/top-app/schedtune.boost ] && echo 30 > /dev/stune/top-app/schedtune.boost; [ -e /dev/stune/top-app/schedtune.prefer_idle ] && echo 1 > /dev/stune/top-app/schedtune.prefer_idle; [ -e /dev/cpuctl/top-app/cpu.uclamp.min ] && echo 20 > /dev/cpuctl/top-app/cpu.uclamp.min; true",
        "[ -e /dev/stune/top-app/schedtune.boost ] && echo 0 > /dev/stune/top-app/schedtune.boost; [ -e /dev/stune/top-app/schedtune.prefer_idle ] && echo 0 > /dev/stune/top-app/schedtune.prefer_idle; [ -e /dev/cpuctl/top-app/cpu.uclamp.min ] && echo 0 > /dev/cpuctl/top-app/cpu.uclamp.min; true"),
    Tweak("io", "root", "Storage I/O tuning", "read_ahead 1024KB, no entropy/iostats, no merges", true,
        "for q in /sys/block/*/queue; do echo 1024 > \$q/read_ahead_kb; echo 0 > \$q/add_random; echo 0 > \$q/iostats; echo 2 > \$q/nomerges; done; true",
        "for q in /sys/block/*/queue; do echo 128 > \$q/read_ahead_kb; echo 1 > \$q/add_random; echo 1 > \$q/iostats; echo 0 > \$q/nomerges; done; true"),
    Tweak("vm", "root", "Memory (VM) tuning", "swappiness 40, vfs_cache_pressure 50", true,
        "echo 40 > /proc/sys/vm/swappiness; echo 50 > /proc/sys/vm/vfs_cache_pressure",
        "echo 60 > /proc/sys/vm/swappiness; echo 100 > /proc/sys/vm/vfs_cache_pressure"),
    Tweak("thermaleng", "root", "Stop thermal engine", "Stops vendor thermal daemons. DANGEROUS: can overheat the phone.", true,
        "stop thermal-engine; stop thermald; stop vendor.thermal-engine; true",
        "start thermal-engine; start thermald; start vendor.thermal-engine; true", risky = true)
)

val CHOICES = listOf(
    Choice("refresh", "screen", "Refresh rate", "Lock the display refresh rate", false, listOf(
        "Auto" to "settings delete system min_refresh_rate; settings delete system peak_refresh_rate; settings delete system user_refresh_rate",
        "60" to rr(60), "90" to rr(90), "120" to rr(120), "144" to rr(144), "165" to rr(165))),
    Choice("renderer", "screen", "HWUI renderer", "Affects apps launched afterwards (restart the game)", false, listOf(
        "Default" to "setprop debug.hwui.renderer ''",
        "Skia GL" to "setprop debug.hwui.renderer skiagl",
        "Skia Vulkan" to "setprop debug.hwui.renderer skiavk")),
    Choice("governor", "root", "CPU governor", "Applies to all cores", true,
        listOf("performance", "schedutil", "conservative", "powersave").map { g ->
            g to "for c in $CPUF; do chmod 644 \$c/scaling_governor; echo $g > \$c/scaling_governor; done" }),
    Choice("sched", "root", "I/O scheduler", "For sd*/mmcblk*/nvme* block devices", true,
        listOf("none", "mq-deadline", "kyber", "bfq").map { s ->
            s to "for q in /sys/block/sd*/queue /sys/block/mmcblk*/queue /sys/block/nvme*/queue; do echo $s > \$q/scheduler; done 2>/dev/null; true" }),
    Choice("swap", "root", "Swappiness", "Lower = keeps more apps in RAM, higher = more zRAM use", true,
        listOf("10", "30", "60", "100").map { v -> v to "echo $v > /proc/sys/vm/swappiness" }),
    Choice("tcp", "root", "TCP congestion control", "Network latency tuning", true,
        listOf("cubic", "bbr", "westwood").map { v -> v to "sysctl -w net.ipv4.tcp_congestion_control=$v" })
)

private fun rr(hz: Int) =
    "settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz; settings put system user_refresh_rate $hz"

val PRESETS: Map<String, Set<String>> = run {
    val balanced = setOf("anim0", "lowlat", "scanoff", "blur")
    val perf = balanced + setOf("fixedperf", "dnd", "abatt", "standby", "autobright", "longpress", "multipress", "stune", "io", "vm")
    val extreme = perf + setOf("hwoverlay", "thermal", "doze", "cpumax", "gpumax", "allcores", "pointer")
    mapOf("Eco" to emptySet(), "Balanced" to balanced, "Performance" to perf, "Extreme" to extreme)
}

val RAM_ACTIONS = listOf(
    Action("Quick clean", "Kill cached background processes + trim app caches", false,
        "am kill-all; pm trim-caches 999999999999; true", false),
    Action("Force-stop all 3rd-party apps", "Stops every user app except RedBoost", false,
        "for p in \$(pm list packages -3 | cut -d: -f2); do [ \"\$p\" != \"com.redboost.app\" ] && am force-stop \$p; done; true", false),
    Action("Deep clean (ROOT)", "sync + drop_caches + compact memory + kill background", true,
        "sync; echo 3 > /proc/sys/vm/drop_caches; echo 1 > /proc/sys/vm/compact_memory; am kill-all; true", false),
    Action("Clear ALL app caches (ROOT)", "Deletes cache folders of every app", true,
        "rm -rf /data/data/*/cache/* /sdcard/Android/data/*/cache/* 2>/dev/null; pm trim-caches 999999999999; true", false)
)

val INFO_ACTIONS = listOf(
    Action("CPU / GPU / temps", "Governors, frequencies, thermal zones", false,
        "for c in $CPUF; do echo \$c: \$(cat \$c/scaling_governor) \$(cat \$c/scaling_cur_freq)/\$(cat \$c/cpuinfo_max_freq); done; cat /sys/class/kgsl/kgsl-3d0/gpuclk /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null; for z in /sys/class/thermal/thermal_zone*; do echo \$(cat \$z/type) \$(cat \$z/temp); done | head -15"),
    Action("GPU / Vulkan info", "Platform, GLES version, Vulkan", false,
        "getprop ro.board.platform; getprop ro.hardware.vulkan; getprop ro.opengles.version; dumpsys SurfaceFlinger | grep -i -E 'GLES|GL_|Vulkan' | head -8"),
    Action("Touch node scan", "Find vendor touch / game-mode / sampling-rate nodes", false,
        "ls /proc/touchpanel /sys/class/touch 2>/dev/null; find /sys/devices/platform -maxdepth 6 \\( -iname '*sample*' -o -iname '*report_rate*' -o -iname '*game*' -o -iname '*touch_boost*' \\) 2>/dev/null | head -40"),
    Action("Sensor info", "Gyro/accelerometer rates (sensorservice)", false,
        "dumpsys sensorservice | grep -i -E 'gyro|accel' | head -12")
)

// ---------------- per-game config & storage ----------------
data class GameCfg(val mode: Int = 2, val fps: Int = 0, val scale: Int = 100)

fun gameModeCmd(pkg: String, c: GameCfg): String {
    val f = if (c.fps > 0) " --fps ${c.fps}" else ""
    val d = if (c.scale < 100) " --downscale ${String.format(Locale.US, "%.2f", c.scale / 100f)}" else ""
    return "cmd game set --mode ${c.mode}$f$d $pkg || cmd game mode ${c.mode} $pkg"
}

object Store {
    lateinit var sp: SharedPreferences
    val on = mutableStateMapOf<String, Boolean>()
    var origW = 0
    var origH = 0

    fun init(c: Context) {
        sp = c.getSharedPreferences("rb", 0)
        for ((k, v) in sp.all) if (k.startsWith("t_") && v is Boolean) on[k.removePrefix("t_")] = v
        if (!sp.contains("ow")) {
            @Suppress("DEPRECATION")
            val dm = DisplayMetrics().also { (c.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(it) }
            sp.edit().putInt("ow", minOf(dm.widthPixels, dm.heightPixels)).putInt("oh", maxOf(dm.widthPixels, dm.heightPixels)).apply()
        }
        origW = sp.getInt("ow", 0); origH = sp.getInt("oh", 0)
    }

    fun set(id: String, v: Boolean) { on[id] = v; sp.edit().putBoolean("t_$id", v).apply() }

    fun game(pkg: String): GameCfg {
        val p = sp.getString("g_$pkg", null)?.split(",")?.mapNotNull { it.toIntOrNull() }
        return if (p != null && p.size == 3) GameCfg(p[0], p[1], p[2]) else GameCfg()
    }
    fun saveGame(pkg: String, c: GameCfg) { sp.edit().putString("g_$pkg", "${c.mode},${c.fps},${c.scale}").apply() }
}
