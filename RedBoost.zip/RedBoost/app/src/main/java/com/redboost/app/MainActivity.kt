package com.redboost.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private val binderL = Shizuku.OnBinderReceivedListener { Sh.refreshShizuku() }
    private val deadL = Shizuku.OnBinderDeadListener { Sh.refreshShizuku() }
    private val permL = Shizuku.OnRequestPermissionResultListener { _, _ -> Sh.refreshShizuku() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        Shizuku.addBinderReceivedListenerSticky(binderL)
        Shizuku.addBinderDeadListener(deadL)
        Shizuku.addRequestPermissionResultListener(permL)
        Sh.refreshShizuku()
        lifecycleScope.launch { Sh.detectRoot() }
        setContent { RedTheme { App() } }
    }

    override fun onResume() { super.onResume(); Sh.refreshShizuku() }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderL)
        Shizuku.removeBinderDeadListener(deadL)
        Shizuku.removeRequestPermissionResultListener(permL)
        super.onDestroy()
    }
}
