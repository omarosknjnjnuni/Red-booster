package com.redboost.app

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

val Rd = Color(0xFFFF1744)
val Cy = Color(0xFF00E5FF)
val Bk = Color(0xFF0B0B10)
val Cd = Color(0xFF16161F)
val Gr = Color(0xFF9A9AA8)

@Composable
fun RedTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Rd, secondary = Cy, background = Bk, surface = Cd,
        onBackground = Color.White, onSurface = Color.White, onPrimary = Color.White,
        secondaryContainer = Color(0xFF3A0D16), onSecondaryContainer = Color.White
    ),
    content = content
)

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val tabs: List<Pair<String, ImageVector>> = listOf(
        "Home" to Icons.Default.Home, "Shizuku" to Icons.Default.Settings, "Root" to Icons.Default.Lock,
        "RAM" to Icons.Default.Delete, "Screen" to Icons.Default.Star, "Tools" to Icons.Default.Build
    )
    Scaffold(
        containerColor = Bk, contentColor = Color.White,
        bottomBar = {
            Column {
                Text(Engine.status, fontSize = 11.sp, color = Cy, maxLines = 2,
                    modifier = Modifier.fillMaxWidth().background(Cd).padding(horizontal = 10.dp, vertical = 5.dp))
                NavigationBar(containerColor = Cd, contentColor = Color.White) {
                    tabs.forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Rd, selectedTextColor = Rd, indicatorColor = Color(0xFF3A0D16),
                                unselectedIconColor = Gr, unselectedTextColor = Gr
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen()
                1 -> ShizukuScreen()
                2 -> RootScreen()
                3 -> RamScreen()
                4 -> ScreenTab()
                else -> ToolsScreen()
            }
        }
    }
    Engine.output?.let {
        AlertDialog(
            onDismissRequest = { Engine.output = null },
            confirmButton = { TextButton(onClick = { Engine.output = null }) { Text("OK") } },
            title = { Text("Output") },
            text = { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.verticalScroll(rememberScrollState())) }
        )
    }
}

// ---------------- shared components ----------------
@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp), content = content
)

@Composable
fun Box2(title: String, content: @Composable ColumnScope.() -> Unit) = Card(
    colors = CardDefaults.cardColors(containerColor = Cd, contentColor = Color.White), modifier = Modifier.fillMaxWidth()
) {
    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, color = Rd, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        content()
    }
}

@Composable
fun TweakRow(t: Tweak) {
    if (Build.VERSION.SDK_INT < t.minSdk) return
    val ok = Sh.canRun(t.root)
    var confirm by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.weight(1f)) {
            Text(t.title + if (t.root) "  [ROOT]" else "", color = if (ok) Color.White else Gr, fontSize = 14.sp)
            Text(t.desc, fontSize = 11.sp, color = Gr)
        }
        if (t.off != null) {
            Switch(checked = Store.on[t.id] == true, enabled = ok,
                onCheckedChange = { v -> if (v && t.risky) confirm = true else Engine.toggle(t, v) })
        } else {
            Button(onClick = { Engine.exec(t.title, t.on, t.root) }, enabled = ok) { Text("Run") }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        confirmButton = { TextButton(onClick = { confirm = false; Engine.toggle(t, true) }) { Text("Enable anyway", color = Rd) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        icon = { Icon(Icons.Default.Warning, null, tint = Rd) },
        title = { Text("Warning") },
        text = { Text("${t.title}\n\nThis can overheat the device or damage the battery. Use at your own risk and watch the temperature.") }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Chips(opts: List<Pair<String, Int>>, sel: Int, on: (Int) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        opts.forEach { (l, v) ->
            if (v == sel) Button(onClick = { on(v) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(l) }
            else OutlinedButton(onClick = { on(v) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(l) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChoiceRow(c: Choice) {
    if (Build.VERSION.SDK_INT < c.minSdk) return
    val ok = Sh.canRun(c.root)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(c.title + if (c.root) "  [ROOT]" else "", color = if (ok) Color.White else Gr, fontSize = 14.sp)
        Text(c.desc, fontSize = 11.sp, color = Gr)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            c.options.forEach { (label, cmd) ->
                OutlinedButton(onClick = { Engine.exec("${c.title}: $label", cmd, c.root) }, enabled = ok,
                    contentPadding = PaddingValues(horizontal = 12.dp)) { Text(label) }
            }
        }
    }
}

@Composable
fun ActionRow(a: Action) {
    val ok = Sh.canRun(a.root)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.weight(1f)) {
            Text(a.title, color = if (ok) Color.White else Gr, fontSize = 14.sp)
            Text(a.desc, fontSize = 11.sp, color = Gr)
        }
        Button(onClick = { Engine.exec(a.title, a.cmd, a.root, a.show) }, enabled = ok) { Text("Run") }
    }
}

// ---------------- HOME ----------------
data class AppItem(val pkg: String, val label: String, val game: Boolean)

@Suppress("DEPRECATION")
fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0).map {
        val ai = it.activityInfo.applicationInfo
        AppItem(ai.packageName, it.loadLabel(pm).toString(),
            ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0)
    }.distinctBy { it.pkg }.sortedWith(compareByDescending<AppItem> { it.game }.thenBy { it.label.lowercase() })
}

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pkg by remember { mutableStateOf(Store.sp.getString("last", null)) }
    var cfg by remember(pkg) { mutableStateOf(pkg?.let { Store.game(it) } ?: GameCfg()) }
    var pick by remember { mutableStateOf(false) }
    var extreme by remember { mutableStateOf(false) }
    var overlay by remember { mutableStateOf(false) }
    val label = remember(pkg) { pkg?.let { p -> runCatching { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(p, 0)).toString() }.getOrDefault(p) } ?: "No game selected" }

    Page {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(painterResource(R.drawable.ic_logo), null, Modifier.size(64.dp))
            Column {
                Text("RedBoost", fontSize = 26.sp, fontWeight = FontWeight.Black, color = Rd)
                Text("Game performance suite", color = Gr, fontSize = 12.sp)
            }
        }
        Box2("Access") {
            Text("Root: " + if (Sh.hasRoot) "✔ available" else "✖ not detected")
            Text("Shizuku: " + when { Sh.shizuku -> "✔ granted"; Sh.shizukuAlive -> "running — permission needed"; else -> "✖ not running" })
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { scope.launch { Sh.detectRoot(); Sh.refreshShizuku() } }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Re-check") }
                OutlinedButton(onClick = {
                    if (Sh.shizukuAlive && !Sh.shizuku) runCatching { Shizuku.requestPermission(100) }
                    else ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { ctx.startActivity(it) }
                        ?: Toast.makeText(ctx, "Install Shizuku first", Toast.LENGTH_LONG).show()
                }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text(if (Sh.shizukuAlive && !Sh.shizuku) "Grant Shizuku" else "Open Shizuku") }
            }
        }
        Box2("Presets") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Eco", "Balanced", "Performance", "Extreme").forEach { n ->
                    Button(onClick = { if (n == "Extreme") extreme = true else Engine.preset(n) },
                        modifier = Modifier.weight(1f), contentPadding = PaddingValues(2.dp)) { Text(n, fontSize = 11.sp, maxLines = 1) }
                }
            }
            Text("Eco = restore defaults. Presets only touch what your access level allows.", fontSize = 11.sp, color = Gr)
        }
        Box2("Game Space") {
            OutlinedButton(onClick = { pick = true }) { Text(label) }
            val p = pkg
            if (p != null) {
                fun save(c: GameCfg) { cfg = c; Store.saveGame(p, c) }
                Text("Game mode", fontSize = 12.sp, color = Gr)
                Chips(listOf("Standard" to 1, "Performance" to 2, "Battery" to 3), cfg.mode) { save(cfg.copy(mode = it)) }
                Text("FPS cap (Android 13+)", fontSize = 12.sp, color = Gr)
                Chips(listOf("Default" to 0, "30" to 30, "60" to 60, "90" to 90, "120" to 120), cfg.fps) { save(cfg.copy(fps = it)) }
                Text("Render scale", fontSize = 12.sp, color = Gr)
                Chips(listOf("100%" to 100, "90%" to 90, "80%" to 80, "70%" to 70, "60%" to 60), cfg.scale) { save(cfg.copy(scale = it)) }
                Button(onClick = { Engine.boostAndPlay(ctx, p, cfg) }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text("⚡ BOOST & PLAY", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { Engine.exec("Game mode", gameModeCmd(p, cfg), false) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Apply mode only") }
                    OutlinedButton(onClick = { Engine.exec("Optimize (dexopt)", "cmd package compile -m speed -f $p", false, true) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Optimize app") }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Switch(checked = overlay, onCheckedChange = { v ->
                    overlay = v
                    if (v && !Settings.canDrawOverlays(ctx)) {
                        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                    } else if (v) ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
                    else ctx.stopService(Intent(ctx, OverlayService::class.java))
                })
                Text("Energy-Cube HUD overlay (RAM / temp / battery / CPU / Hz)", fontSize = 12.sp)
            }
        }
    }
    if (pick) {
        val apps = remember { loadApps(ctx) }
        AlertDialog(onDismissRequest = { pick = false }, confirmButton = {}, title = { Text("Choose game") },
            text = {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(apps) { a ->
                        Text((if (a.game) "🎮 " else "") + a.label, Modifier.fillMaxWidth().clickable {
                            pkg = a.pkg; Store.sp.edit().putString("last", a.pkg).apply(); pick = false
                        }.padding(vertical = 10.dp))
                    }
                }
            })
    }
    if (extreme) AlertDialog(
        onDismissRequest = { extreme = false },
        confirmButton = { TextButton(onClick = { extreme = false; Engine.preset("Extreme") }) { Text("Apply", color = Rd) } },
        dismissButton = { TextButton(onClick = { extreme = false }) { Text("Cancel") } },
        icon = { Icon(Icons.Default.Warning, null, tint = Rd) }, title = { Text("Extreme preset") },
        text = { Text("Locks CPU/GPU at max, disables thermal throttling and more. Phone will get HOT and drain fast. Use 'Eco' to restore afterwards.") }
    )
}

// ---------------- SHIZUKU ----------------
@Composable
fun ShizukuScreen() = Page {
    Box2("Performance (Shizuku / ADB level)") {
        if (!Sh.canRun(false)) Text("Start Shizuku and grant permission (Home → Access).", color = Rd, fontSize = 12.sp)
        TOGGLES.filter { it.tab == "perf" }.forEach { TweakRow(it) }
    }
    Box2("Touch") { TOGGLES.filter { it.tab == "touch" }.forEach { TweakRow(it) } }
}

// ---------------- ROOT ----------------
@Composable
fun RootScreen() = Page {
    Box2("Root tweaks") {
        if (!Sh.hasRoot) Text("Root not detected — these are locked.", color = Rd, fontSize = 12.sp)
        TOGGLES.filter { it.tab == "root" }.forEach { TweakRow(it) }
    }
    Box2("Governors & kernel") { CHOICES.filter { it.tab == "root" }.forEach { ChoiceRow(it) } }
    Box2("Info") { ActionRow(INFO_ACTIONS[0]) }
}

// ---------------- RAM ----------------
@Composable
fun RamScreen() {
    val ctx = LocalContext.current
    var used by remember { mutableFloatStateOf(0f) }
    var txt by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            val (u, free, total) = ramInfo(ctx)
            val (t, l) = batteryInfo(ctx)
            used = u; txt = "Used ${(u * 100).toInt()}%  •  free $free MB / $total MB  •  battery $l% @ ${"%.1f".format(t)}°C"
            delay(1500)
        }
    }
    Page {
        Box2("Memory") {
            LinearProgressIndicator(progress = { used }, modifier = Modifier.fillMaxWidth().height(10.dp), color = Rd, trackColor = Color(0xFF2A2A36))
            Text(txt, fontSize = 12.sp, color = Gr)
        }
        Box2("Clean") { RAM_ACTIONS.forEach { ActionRow(it) } }
        Box2("RedBoost cache") {
            Button(onClick = { ctx.cacheDir.deleteRecursively(); Toast.makeText(ctx, "Cleared", Toast.LENGTH_SHORT).show() }) { Text("Clear own cache") }
        }
    }
}

// ---------------- SCREEN (color + refresh + GFX) ----------------
@Composable
fun ScreenTab() {
    var sat by remember { mutableFloatStateOf(1f) }
    var con by remember { mutableFloatStateOf(1f) }
    var bri by remember { mutableFloatStateOf(0f) }
    var warm by remember { mutableFloatStateOf(0f) }
    fun apply() = Engine.exec("Color", colorCmd(sat, con, bri, warm), false)
    fun set(s: Float, c: Float, b: Float, w: Float) { sat = s; con = c; bri = b; warm = w; apply() }
    val ok = Sh.canRun(false)
    Page {
        Box2("Colors (SurfaceFlinger)") {
            if (!ok) Text("Needs Shizuku or Root. Some devices block this call.", color = Rd, fontSize = 12.sp)
            @Composable fun slider(n: String, v: Float, r: ClosedFloatingPointRange<Float>, f: (Float) -> Unit) {
                Text("$n: ${"%.2f".format(v)}", fontSize = 12.sp, color = Gr)
                Slider(value = v, onValueChange = f, valueRange = r, enabled = ok, onValueChangeFinished = { apply() })
            }
            slider("Saturation", sat, 0f..2f) { sat = it }
            slider("Contrast", con, 0.5f..1.5f) { con = it }
            slider("Brightness offset", bri, -0.3f..0.3f) { bri = it }
            slider("Warmth", warm, -1f..1f) { warm = it }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { set(1.4f, 1.1f, 0f, 0f) }, enabled = ok, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Vivid") }
                OutlinedButton(onClick = { set(1.25f, 1.2f, 0.02f, 0f) }, enabled = ok, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Game pop") }
                OutlinedButton(onClick = { set(1f, 1f, 0f, 0.5f) }, enabled = ok, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Warm") }
                Button(onClick = { sat = 1f; con = 1f; bri = 0f; warm = 0f; Engine.exec("Color reset", COLOR_RESET, false) }, enabled = ok, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Reset") }
            }
        }
        Box2("Display") { CHOICES.filter { it.id == "refresh" }.forEach { ChoiceRow(it) } }
        Box2("GFX tool") {
            CHOICES.filter { it.id == "renderer" }.forEach { ChoiceRow(it) }
            TOGGLES.filter { it.tab == "screen" }.forEach { TweakRow(it) }
            ResolutionRow()
            ActionRow(INFO_ACTIONS[1])
        }
    }
}

@Composable
fun ResolutionRow() {
    val ow = Store.origW; val oh = Store.origH
    val ok = Sh.canRun(false) && ow > 0
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Render resolution", fontSize = 14.sp, color = if (ok) Color.White else Gr)
        Text("Lower resolution = more FPS (original ${ow}x$oh)", fontSize = 11.sp, color = Gr)
        Chips(listOf("100%" to 100, "90%" to 90, "80%" to 80, "70%" to 70), -1) { p ->
            val w = (ow * p / 100) / 2 * 2; val h = (oh * p / 100) / 2 * 2
            Engine.exec("Resolution $p%", if (p == 100) "wm size reset" else "wm size ${w}x$h", false)
        }
    }
}

// ---------------- TOOLS ----------------
@Composable
fun ToolsScreen() = Page {
    Box2("Touch & sensors info") { INFO_ACTIONS.drop(2).forEach { ActionRow(it) } }
    SensorsCard()
    ConsoleCard()
    Box2("About") {
        Text("RedBoost 1.0 — Root + Shizuku game booster.\nFeatures needing kernel nodes (CPU/GPU, I/O, touch rate) vary per device. Use at your own risk.", fontSize = 12.sp, color = Gr)
    }
}

@Composable
fun SensorsCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var g by remember { mutableStateOf(FloatArray(3)) }
    var a by remember { mutableStateOf(FloatArray(3)) }
    var bias by remember { mutableStateOf<FloatArray?>(null) }
    var sampling by remember { mutableStateOf(false) }
    val acc = remember { FloatArray(4) }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                if (e.sensor.type == Sensor.TYPE_GYROSCOPE) {
                    g = e.values.clone()
                    if (sampling) { for (i in 0..2) acc[i] += e.values[i]; acc[3]++ }
                } else a = e.values.clone()
            }
            override fun onAccuracyChanged(s: Sensor?, x: Int) {}
        }
        sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let { sm.registerListener(l, it, SensorManager.SENSOR_DELAY_GAME) }
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sm.registerListener(l, it, SensorManager.SENSOR_DELAY_GAME) }
        onDispose { sm.unregisterListener(l) }
    }
    Box2("Gyro / Accelerometer") {
        Text("Gyro (rad/s): " + g.joinToString("  ") { "%.3f".format(it) }, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        Text("Accel (m/s²): " + a.joinToString("  ") { "%.2f".format(it) }, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        bias?.let { b ->
            val worst = b.maxOf { kotlin.math.abs(it) }
            Text("Drift: " + b.joinToString("  ") { "%.4f".format(it) } + if (worst > 0.02f) "  ⚠ high — recalibrate on a flat surface" else "  ✔ good", fontSize = 12.sp, color = Cy)
        }
        Button(onClick = {
            scope.launch {
                acc.fill(0f); sampling = true; delay(2000); sampling = false
                if (acc[3] > 0) bias = floatArrayOf(acc[0] / acc[3], acc[1] / acc[3], acc[2] / acc[3])
            }
        }) { Text("Measure drift (keep phone still)") }
    }
}

@Composable
fun ConsoleCard() {
    val scope = rememberCoroutineScope()
    var cmd by remember { mutableStateOf("") }
    var asRoot by remember { mutableStateOf(false) }
    var out by remember { mutableStateOf("") }
    Box2("Console") {
        OutlinedTextField(cmd, { cmd = it }, label = { Text("Command") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(asRoot, { asRoot = it }); Text("root")
            Button(onClick = {
                scope.launch {
                    out = if (Sh.canRun(asRoot)) withContext(Dispatchers.IO) { Sh.run(cmd, asRoot) } else "ERR: no access"
                }
            }) { Text("Run") }
        }
        if (out.isNotEmpty()) Text(out, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
    }
}
