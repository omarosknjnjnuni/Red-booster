package com.redboost.app

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

object Engine {
    var status by mutableStateOf("Ready")
    var output by mutableStateOf<String?>(null)
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    suspend fun execNow(label: String, cmd: String, root: Boolean, show: Boolean = false): String {
        if (!Sh.canRun(root)) {
            status = "✖ $label — needs ${if (root) "ROOT" else "Shizuku or Root"}"
            return ""
        }
        status = "… $label"
        val r = withContext(Dispatchers.IO) { Sh.run(cmd, root) }
        if (show) output = r.ifBlank { "(empty)" }
        status = if (r.startsWith("ERR")) "✖ $label: $r" else "✔ $label"
        return r
    }

    fun exec(label: String, cmd: String, root: Boolean, show: Boolean = false) {
        scope.launch { execNow(label, cmd, root, show) }
    }

    fun toggle(t: Tweak, enable: Boolean) {
        Store.set(t.id, enable)
        exec(t.title, if (enable) t.on else (t.off ?: t.on), t.root)
    }

    suspend fun presetNow(name: String) {
        val ids = PRESETS[name] ?: return
        for (t in TOGGLES) {
            if (t.off == null || Build.VERSION.SDK_INT < t.minSdk || !Sh.canRun(t.root)) continue
            val en = t.id in ids
            Store.set(t.id, en)
            execNow(t.title, if (en) t.on else t.off, t.root)
        }
        status = "✔ Preset $name applied"
    }

    fun preset(name: String) { scope.launch { presetNow(name) } }

    fun boostAndPlay(ctx: Context, pkg: String, cfg: GameCfg) {
        scope.launch {
            status = "⚡ Boosting…"
            presetNow("Performance")
            execNow("RAM clean", "am kill-all; pm trim-caches 999999999999; true", false)
            execNow("Game mode", gameModeCmd(pkg, cfg), false)
            ctx.packageManager.getLaunchIntentForPackage(pkg)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(it)
            }
            status = "✔ Boost done — good game!"
        }
    }
}

// ---------- color matrix via SurfaceFlinger (saturation / contrast / brightness / warmth) ----------
fun colorCmd(sat: Float, con: Float, bri: Float, warm: Float): String {
    val lw = floatArrayOf(0.213f, 0.715f, 0.072f)
    val a = Array(3) { i -> FloatArray(3) { j -> ((1 - sat) * lw[j] + if (i == j) sat else 0f) * con } }
    val rs = 1f + warm * 0.15f
    val bs = 1f - warm * 0.15f
    for (j in 0..2) { a[0][j] *= rs; a[2][j] *= bs }
    val t = 0.5f * (1 - con) + bri
    val m = floatArrayOf(
        a[0][0], a[1][0], a[2][0], 0f,
        a[0][1], a[1][1], a[2][1], 0f,
        a[0][2], a[1][2], a[2][2], 0f,
        t, t, t, 1f
    )
    return "service call SurfaceFlinger 1015 i32 1 " + m.joinToString(" ") { "f " + String.format(Locale.US, "%.4f", it) }
}
const val COLOR_RESET = "service call SurfaceFlinger 1015 i32 0"

// ---------- system stats ----------
fun ramInfo(ctx: Context): Triple<Float, Long, Long> {
    val mi = ActivityManager.MemoryInfo()
    ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
    return Triple(1f - mi.availMem.toFloat() / mi.totalMem, mi.availMem shr 20, mi.totalMem shr 20)
}

fun batteryInfo(ctx: Context): Pair<Float, Int> {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    return (i?.getIntExtra("temperature", 0) ?: 0) / 10f to (i?.getIntExtra("level", 0) ?: 0)
}

@Suppress("DEPRECATION")
fun hud(ctx: Context): String {
    val (used, _, _) = ramInfo(ctx)
    val (temp, lvl) = batteryInfo(ctx)
    val ghz = runCatching {
        File("/sys/devices/system/cpu/cpu7/cpufreq/scaling_cur_freq").readText().trim().toLong() / 1000
    }.getOrNull()?.let { "$it MHz" } ?: "— MHz"
    val hz = ctx.getSystemService(WindowManager::class.java).defaultDisplay.refreshRate.toInt()
    return "RAM ${(used * 100).toInt()}% | ${"%.1f".format(Locale.US, temp)}°C | $lvl% | $ghz | ${hz}Hz"
}

// ---------- Energy-Cube style HUD overlay ----------
class OverlayService : Service() {
    private var tv: TextView? = null
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { tv?.text = hud(this@OverlayService); h.postDelayed(this, 1000) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rb", "RedBoost", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "rb").setContentTitle("RedBoost HUD running").setSmallIcon(R.drawable.ic_fg).build()
        ServiceCompat.startForeground(this, 1, n, if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
        if (tv == null && Settings.canDrawOverlays(this)) {
            val v = TextView(this).apply {
                setTextColor(0xFFFF1744.toInt()); setBackgroundColor(0x99000000.toInt())
                textSize = 11f; setPadding(14, 6, 14, 6)
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.END; x = 8; y = 24 }
            getSystemService(WindowManager::class.java).addView(v, lp)
            tv = v
        }
        h.removeCallbacks(tick); h.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        tv?.let { runCatching { getSystemService(WindowManager::class.java).removeView(it) } }
        tv = null
        super.onDestroy()
    }
}
