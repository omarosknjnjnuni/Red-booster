package com.redboost.app

import android.content.pm.PackageManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

/** Runs shell commands through Root (su) or Shizuku (ADB-level shell). */
object Sh {
    var hasRoot by mutableStateOf(false)
    var shizuku by mutableStateOf(false)       // alive + permission granted
    var shizukuAlive by mutableStateOf(false)

    fun canRun(needRoot: Boolean) = if (needRoot) hasRoot else (hasRoot || shizuku)

    fun refreshShizuku() {
        shizukuAlive = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        shizuku = try {
            shizukuAlive && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) { false }
    }

    suspend fun detectRoot() {
        hasRoot = withContext(Dispatchers.IO) {
            runCatching { collect(Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))).contains("uid=0") }
                .getOrDefault(false)
        }
    }

    fun run(cmd: String, needRoot: Boolean = false): String = try {
        when {
            hasRoot -> collect(Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)))
            shizuku && !needRoot -> collect(shizukuProc(cmd))
            else -> "ERR: no permission (Root/Shizuku required)"
        }
    } catch (e: Throwable) { "ERR: ${e.message}" }

    // Shizuku.newProcess is private in API 13+, so call it by reflection.
    private fun shizukuProc(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    private fun collect(p: Process): String {
        val o = p.inputStream.bufferedReader().readText()
        val e = p.errorStream.bufferedReader().readText()
        p.waitFor()
        return (o + e).trim()
    }
}
