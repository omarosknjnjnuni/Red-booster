<p align="center"><img src="logo.png" width="140"></p>

# RedBoost ⚡
Game performance suite for Android (Root + Shizuku). Inspired by RedMagic *Game Space*.

## Features
- **Game Space**: per-game mode (Standard/Performance/Battery), FPS cap, render scale, *Boost & Play*, dexopt, Energy-Cube HUD overlay
- **Presets**: Eco / Balanced / Performance / Extreme
- **Shizuku (no root)**: fixed-performance mode, animations, Doze, Adaptive Battery, DND, Wi-Fi low-latency, thermal override, touch timing, refresh-rate lock
- **Root**: CPU governor & freq lock, GPU (Adreno/Mali) lock, schedtune/uclamp boost, I/O scheduler/read-ahead, swappiness, TCP, thermal engine, all cores online
- **RAM**: quick/deep clean, force-stop, cache clearing, live monitor
- **Screen**: saturation / contrast / brightness / warmth, resolution scale, HWUI renderer (Skia GL/Vulkan), MSAA, HW overlays
- **Tools**: gyro/accelerometer live + drift test, touch-node scanner, sensor info, console

## Build
Push to GitHub → **Actions → Build APK** → download artifact `RedBoost-debug-apk`.
Or open in Android Studio (JDK 17) and press Run. Optional: `gradle wrapper --gradle-version 8.7`.

## Use
1. Install [Shizuku](https://shizuku.rikka.app/) and start it (Wireless debugging), or use a rooted phone.
2. Open RedBoost → Home → grant access.

> Kernel-node features differ per device. Extreme preset / thermal tweaks can overheat the phone. Use at your own risk.
